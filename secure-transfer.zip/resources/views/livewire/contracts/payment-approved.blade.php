<div class="mt-5">
    <div class="w-96 h-96 m-auto rounded-xl relative text-white">
        <div class="w-full px-8 absolute top-8">
            <div class="flex justify-center">
                <dl>
                    <h3 class="text-center text-black mb-0 ml-0 font-bold text-2xl"></h3>
                    <div>
                        <i class="fa-regular fa-circle-check bg-success-500 fa-10x rounded-full"></i>
                        <h4 class="text-black text-center mt-2">Payment Release</h4>

                        <h1 class="text-black text-center font-bold text-2xl">Successfully</h1>
                    </div>
                    <br>
                </dl>
            </div>
        </div>
    </div>
</div>
