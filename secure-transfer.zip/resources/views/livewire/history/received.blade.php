<div id="myTabContent">
    <x-history.tab :contracts="$contracts" :tab="$tab"/>
</div>
