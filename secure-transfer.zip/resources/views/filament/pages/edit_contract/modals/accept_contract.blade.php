<div class="sm:col-span-2">
    <dt class="text-sm font-medium text-gray-500">{{ __('lang.qr') }}</dt>
    <dd class="m-2 text-sm text-gray-900">
        {!! $contract->status->qr_code !!}
    </dd>
</div>
