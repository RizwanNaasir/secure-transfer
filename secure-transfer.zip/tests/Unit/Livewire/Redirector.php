<?php

namespace Livewire;

class Redirector
{

}
