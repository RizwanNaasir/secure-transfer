<div>
    {{ $this->table }}
</div>