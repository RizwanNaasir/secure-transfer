



<img src="<?php echo e(asset('assets/images/logo.png')); ?>" <?php echo e($attributes); ?> alt="">
<?php /**PATH D:\laragon\www\secure-transfer\resources\views/components/application-logo.blade.php ENDPATH**/ ?>