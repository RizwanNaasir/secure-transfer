<div class="py-1 sm:px-10 xl:p-12 col-span-2 sm:col-span-1">
    <h3 class="p-4 text-center text-2xl font-bold text-warm-gray-900">
        <?php echo e(__('Contract')); ?>

    </h3>
    <form wire:submit.prevent="submit">
        <?php echo e($this->form); ?>

        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.reactive-button','data' => ['class' => 'w-full mb-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('reactive-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full mb-5']); ?>
            <?php echo e(__('Send')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </form>
</div>
<?php /**PATH D:\laragon\www\secure-transfer\resources\views/livewire/send-contract-from-market.blade.php ENDPATH**/ ?>