<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">

    <meta name="application-name" content="<?php echo e(config('app.name')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name')); ?></title>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    <wireui:scripts />
    <script src="//unpkg.com/alpinejs" defer></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
    <body class="antialiased">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo e($slot ?? ''); ?>


        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('notifications');

$__html = app('livewire')->mount($__name, $__params, 'V1UWITn', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php echo $__env->yieldContent('scripts'); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH D:\laragon\www\secure-transfer\resources\views/layouts/app.blade.php ENDPATH**/ ?>