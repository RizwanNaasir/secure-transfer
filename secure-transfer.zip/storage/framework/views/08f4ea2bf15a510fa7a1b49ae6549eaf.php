<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH D:\laragon\www\secure-transfer\resources\views/livewire/list-transactions.blade.php ENDPATH**/ ?>