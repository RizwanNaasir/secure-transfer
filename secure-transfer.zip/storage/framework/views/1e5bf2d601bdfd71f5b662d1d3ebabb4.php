<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="z-50">
        <section x-data="{modalOpen: false}">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['@click' => 'modalOpen = !modalOpen','class' => 'w-32 bg-purple-600 float-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'modalOpen = !modalOpen','class' => 'w-32 bg-purple-600 float-right']); ?>
                <div class="flex flex-row">
                    Top up wallet
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <div class="hidden" x-bind:class="{'hidden' : !modalOpen}">
                <div
                    x-show="modalOpen"
                    x-transition:enter="transition ease-out duration-300 transform opacity-0"
                    x-transition:enter-start="opacity-0 translate-y-4"
                    x-transition:enter-end="opacity-100 translate-y-0"
                    class="                       z-100
                                                  bg-black bg-opacity-90
                                                  fixed
                                                  top-0
                                                  left-0
                                                  w-full
                                                  min-h-screen
                                                  h-full
                                                  flex
                                                  items-center
                                                  justify-center
                                                  px-4
                                                  py-5
                                                "
                >
                    <div
                        @click.outside="modalOpen = false"
                        class="
                                                    w-full
                                                    max-w-[570px]
                                                    rounded-[20px]
                                                    bg-white
                                                    py-12
                                                    px-8
                                                    md:py-[60px] md:px-[70px]
                                                    text-center
                                                  "
                    >

                        <div class="relative bg-white rounded-lg ">
                            <div class="px-6 py-6 lg:px-8">
                                <h3 class="mb-4 text-xl font-medium text-gray-900">Add Your Top up Wallet</h3>
                                <form class="space-y-6" action="<?php echo e(route('stripe.top-up-wallet')); ?>">
                                    <div>
                                        <input type="number" max="10000" name="amount" wire:model="shop_url"
                                               id="amount"
                                               class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  "
                                               placeholder="Enter Amount"
                                               value="" required>
                                    </div>

                                    <button type="submit">
                                        <div class="flex flex-row bg-purple-700 px-5 text-white py-2 rounded-lg">
                                            Pay Now !
                                        </div>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="z-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wallet-overview');

$__html = app('livewire')->mount($__name, $__params, 'FmjMWdl', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
<div class="z-2">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('list-transactions');

$__html = app('livewire')->mount($__name, $__params, 'y7Vbfdz', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\secure-transfer\resources\views/filament/app/pages/wallet.blade.php ENDPATH**/ ?>