<div>
    {{$this->table}}
</div>
