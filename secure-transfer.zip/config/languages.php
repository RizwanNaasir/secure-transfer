<?php
return [
    'en' => [
        'display' => 'Eng',
        'flag-icon' => 'us'
    ],
    'fr' => [
        'display' => 'Fr',
        'flag-icon' => 'fr'
    ],
];
