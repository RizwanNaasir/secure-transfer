<div>
    <div class="space-y-6 sm:space-y-5">
        {{$this->table}}
    </div>
</div>
